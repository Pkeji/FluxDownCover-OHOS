---
name: upload-harmonyos-hap-to-github
description: This skill should be used when a user asks to upload/share a HarmonyOS build artifact (unsigned or signed .hap/.app) to GitHub — e.g. "把未签名的hap上传到GitHub" / "发个测试包". It covers locating the latest build output, reusing the macOS-keychain GitHub token for the REST API, and publishing via a GitHub Release asset (the repo deliberately gitignores build artifacts, so committing to source is wrong).
agent_created: true
---

# Upload HarmonyOS HAP/APP to GitHub (Release asset)

Publish a HarmonyOS build artifact to GitHub as a **Release attachment** (not committed to
source — the project `.gitignore` excludes `**/build/`, `*.hap`, `*.app`).

## When to use
- User says "上传 hap/app 到 GitHub", "发个测试包", "把未签名包发到 GitHub".
- Applies to this repo (`Pkeji/FluxDownCover-OHOS`) and any HarmonyOS project whose
  `.gitignore` excludes build outputs.

## Workflow

### 1. Locate the latest artifact
Search build outputs for the requested file (unsigned preferred unless "signed" stated):
```
find . -path ./oh_modules -prune -o \( -name "*-unsigned.hap" -o -name "*.hap" -o -name "*.app" \) -print
```
Pick the **newest** matching file. Confirm version via `pack.info` (JSON in the same dir):
`bundleName`, `version.name`, `version.code`, `deviceType`.

### 2. Get a GitHub token from the macOS keychain (no secret handling needed)
The repo remote is `https://github.com/<owner>/<repo>.git`; `osxkeychain` usually caches a PAT.
```
CRED=$(printf 'protocol=https\nhost=github.com\n' | git credential fill </dev/null 2>/dev/null)
TOKEN=$(echo "$CRED" | awk -F= '/^password=/{print $2}')
```
Validate (also reveals login + scopes):
```
curl -s -H "Authorization: Bearer $TOKEN" -H "Accept: application/vnd.github+json" https://api.github.com/user
```
Requires `repo` scope. If empty → user must provide a PAT or run `gh auth login`.

### 3. Decide the release target
- List existing releases: `GET /repos/<owner>/<repo>/releases` (parse `tag_name`, `id`, `assets`).
- If a release with the intended tag already exists and has **no asset**, upload to it.
- If not, `POST /repos/<owner>/<repo>/releases` with
  `{"tag_name":..., "target_commitish":"main", "name":..., "body":..., "prerelease":true}`.
- ⚠️ A tag collision returns HTTP 422 `already_exists` — reuse the existing release id instead
  of retrying with a new tag.

### 4. Upload the asset
```
NAME=fluxdowncover-default-unsigned.hap
LABEL=$(python3 -c "import urllib.parse;print(urllib.parse.quote('中文标签'))")   # MUST URL-encode
curl -s -w "\nHTTP=%{http_code}\n" -X POST \
  -H "Authorization: Bearer $TOKEN" \
  -H "Accept: application/vnd.github+json" \
  -H "Content-Type: application/octet-stream" \
  --data-binary @"<local-hap>" \
  "https://uploads.github.com/repos/<owner>/<repo>/releases/<id>/assets?name=$NAME&label=$LABEL"
```
- Expect **HTTP 201** and JSON with `"state":"uploaded"`.
- **Chinese `label` must be URL-encoded** or GitHub returns HTTP 400 "Bad request".
- `name` should stay ASCII (e.g. `fluxdowncover-default-unsigned.hap`).
- Verify: `GET /repos/<owner>/<repo>/releases/<id>/assets` → lists `name`,`size`,`state`.

### 5. Report
Give the human the release URL:
`https://github.com/<owner>/<repo>/releases/tag/<tag_name>`
and the asset download link. Note deviceType / version from `pack.info`.

## Pitfalls
- Never `git add` the hap (gitignored; pollutes source tree).
- Don't push a new branch by accident — use Release assets, not commits.
- `timeout` is unavailable in zsh here; use `curl -w` / `git ... </dev/null` to avoid hangs.
- Cached creds may be an OAuth token without `repo` scope → test `/user` first.
